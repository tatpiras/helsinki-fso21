import React from 'react'

const Header = ({headerName}) => {
    return (
        <h2>{headerName}</h2>
    )
}

export default Header